import React, {useState} from 'react'
import List from './components/Child';
import AddToList from './components/Child2';
import "./input.css"

export default function App() {
  const [list, setList] = useState([]);
  return (
    <div className='flex justify-center bg-cyan-800 min-h-screen'>
    <div className='flex justify-center w-fit border-solid border-black border-4 rounded-lg p-5 pb-10 bg-orange-100 h-fit place-self-center'>
      <div>
      <AddToList listArray={list} setListFunction={setList}/>
      <List toDoList={list} removeFromList={setList}/>
      </div>
    </div>
    </div>
  )
}


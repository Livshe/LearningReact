import React from "react";

export default function List(props) {
  const deleteByValue = value => {
    props.removeFromList(oldValues => {
      return oldValues.filter(item => item !== value)
    })
  }
  return (
    <div>
      <div 
        className="flex item-center justify-center pt-4">
        There are {props.toDoList.length} items on your to do list
      </div>
      {props.toDoList.map((item) => (
        <div className="flex item-center justify-center pt-3" key={item}>
          <div className="mr-7">{item.name}</div>
          <button onClick={() => deleteByValue(item)} className='outline outline-2 rounded px-3 bg-white'>Delete</button>
        </div>
      ))}
    </div>
  )
}
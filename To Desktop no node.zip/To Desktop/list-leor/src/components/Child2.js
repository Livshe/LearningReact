import React, {useState}from 'react'

export default function AddToList(props) {
    const [listItem, setListItem] = useState([]);
    
  return (
    <div>
      <h1 className='flex justify-center pt-2 text-2xl'>To Do List</h1>
    <div className='flex space-x-4 flex item-center justify-center pt-5'>
        <div>
          <label for='list_item' className='mr-2'>Add Item:</label>
          <input 
          className='outline outline-2 rounded'
          id='list_item' 
          value={listItem} 
          onChange={(e) => {
            setListItem(e.target.value);
          }}/>
        </div>
        <div>
          <button 
            className='outline outline-2 rounded px-4 bg-white'
            onClick={() => {
            props.setListFunction([
              ...props.listArray,
              {name: listItem}
            ]);
            setListItem("");
          }}>Add to List</button>
        </div>
      </div>
      </div>
  );
}

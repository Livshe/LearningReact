import React from 'react'
import Message from './components/message/Message'
import News from './components/news/News'
import {Link,Route,Routes,useNavigate} from 'react-router-dom'  

export default function App() {
  const navigate = useNavigate();
  const previous = () => {
    navigate(-1);
  }
  const next = () => {
    navigate(1);
  }
  return (
    <>
      <button onClick={previous}>Go previous</button>
      <button onClick={next}>Go Next</button>
      <h3>Parent:</h3>
      <Link to="/message">Message</Link>
      <br/>
      <Link to="/news">News</Link>
      <br/>
      <h3>Child:</h3>

      <Routes>
        <Route path="/message" element={<Message/>}/> | {" "}
        <Route path="/news/*" element={<News/>}/> | {" "}
      </Routes>
    </>
  )
}

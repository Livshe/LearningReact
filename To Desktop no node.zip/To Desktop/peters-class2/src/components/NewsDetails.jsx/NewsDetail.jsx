// use params to send data
// import React from 'react'
// import {useParams} from 'react-router-dom';

// export default function NewsDetail() {
//     const {id,title,content} = useParams();
//     console.log("newDetail",id,title,content)
//   return (
//     <div>NewsDetail
//         <div>
//             <div>id: {id}</div>
//             <div>title: {title}</div>
//             <div>content: {content}</div>
//         </div>
//     </div>
//   )
// }

//use location to send data
import React from 'react'
import {useLocation} from 'react-router-dom';

export default function NewsDetail() {
  const location=useLocation();
    console.log(location.state)
    const {id,title,content} = location.state;
  return (
    <div>NewsDetail
        <div>
            <div>id: {id}</div>
            <div>title: {title}</div>
            <div>content: {content}</div>
        </div>
    </div>
  )
}

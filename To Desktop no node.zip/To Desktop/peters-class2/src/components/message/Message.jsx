import React from 'react'

export default function Message() {
  return (
    <div>Message</div>
  )
}

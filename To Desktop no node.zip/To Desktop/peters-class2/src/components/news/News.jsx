import React, {useState} from 'react'
import {Route, Routes, Link} from "react-router-dom";
import NewsDetail from '../NewsDetails.jsx/NewsDetail';

// sending url with params
// export default function News() {
//     const [news] = useState([
//         {    id: 1,    title: 'news1',    content: 'content1'},
//         {    id: 2,    title: 'news2',    content: 'content2'},
//         {    id: 3,    title: 'news3',    content: 'content3'},
//     ])
//   return (
//     <div>
//         <div>News</div>
//         <ul>
//             {/* item = index */}
//             {news.map((item) => (
//                 <li key={item.id}>
//                     <Link to={`/news/${item.id}/${item.title}/${item.content}`}>{item.title}</Link>
//                 </li>
//             ))}
//         </ul>
//         <Routes>
//             <Route path="/:id/:title/:content" element={<NewsDetail/>}/>
//         </Routes>
//     </div>
//   )
// }

export default function News() {
    const [news] = useState([
        {    id: 1,    title: 'news1',    content: 'content1'},
        {    id: 2,    title: 'news2',    content: 'content2'},
        {    id: 3,    title: 'news3',    content: 'content3'},
    ])
  return (
    <div>
        <div>News</div>
        <ul>
            {/* item = index */}
            {news.map((item) => (
                <li key={item.id}>
                    <Link to={"/news/newsdetail"} state={{id:item.id,title:item.title,content:item.content}}>{item.title}</Link>
                </li>
            ))}
        </ul>
        <Routes>
            <Route path="/newsdetail" element={<NewsDetail/>}/>
        </Routes>
    </div>
  )
}



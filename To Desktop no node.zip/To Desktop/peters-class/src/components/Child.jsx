import React, {useState}from "react";

// export default function Child(props){
    // const {counter} = props;
    // const counter = props.counter;
    // const [childCounter,setChildCounter] = useState(counter);
    // const add =() => {
    //     setChildCounter(childCounter+1);

    // return(
    //     <div>child:{counter}
    //     <button onClick={add}>Child: Increment</button>
    //     childCounter:{childCounter};
    //     </div>
    // )
    //}

    // export default function Child(props){
    //child has permission to access setCounter Function
    // const {setCounter} = props;
    // const changeData = () => {
    //     setCounter(15);
    // }

    // return(
    //     <div>
    //         child:
    //         <button onClick={changeData}>Send data to parent</button>
    //     </div>
    // )
    //}

    //importing data from parents array
    // export default function Child(props) {
    //     const {data} = props;
    //     console.log(data)
    //   return (
    //     <div>
    //         <ul>
    //             {data.map((e)=>{
    //                 return <li key={e.id}>{e.name}</li>
    //             })}
    //             {/* if no unique key is provided */}
    //             {/* {data.map((e,key)=>{
    //                 return <li key={key}>{e.name}</li>
    //             })} */}
    //         </ul>
    //     </div>
    //   )
    // }

    //mapping parent array to buttons
    export default function Child(props) {
        const {data} = props;
        const getButton = (e)=> {
            console.log(e);
        };
        
      return (
        <div>
            <ul>
                {data.map((e)=>(
                    <button onClick={()=>getButton(e)} key={e.id}>{e.name}</button>
                ))}
            </ul>
        </div>
      )
    }


    
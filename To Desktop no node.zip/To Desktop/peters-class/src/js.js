const list = [1,2,3,4,5,6,7,8,9,10];
//e stands for event
//for loop
list.map((e)=>{
    return e;
})
//for loop
list.forEach((e)=>{
    console.log(e);
})
//boolean
list.filter((e)=>{
    return e>5;
})
import React, {useState, useRef} from "react";
import Child from "./components/Child";

//passing state(counter) to child
// export default function App(){
//     const [counter, setCounter]=useState(0);
    // const add = () => {
    //     setCounter(counter+1);
    // }
    // return(
    //     <div>
    //     <button onClick={add}>Increment</button>
    //     <Child counter={counter}/>
    //     </div>
    // )
    // }


    //passes state(setCounter function) from child to parrent
    // export default function App(){
//     const [counter, setCounter]=useState(0);
    // const add = () => {
    //     setCounter(counter+1);
    // }
//     return(
//         <div>
//             Parent:
//             <h1>{counter}</h1>
//             <Child setCounter={setCounter}/>
//         </div>
//     )
// }

// //ref
// export default function App() {
//     const inputRef = useRef();
//     const [data,setData]=useState();
//     const getInput =() => {
//         setData(inputRef.current.value) // set data variable
//     }
//   return (
//     <div>
//         <input ref={inputRef} type="text"/>
//         <button onClick={getInput}>submit</button>
//         {data}
//     </div>
//   )
// }

// //onChange
// export default function App() {
//     const [data, setData]=useState();
//     const getChange = (e) => {
//         setData(e.target.value)
//     }
//   return (
//     <div>
//         <input onChange={getChange}/>
//         {data}
//     </div>
//   )
// }

//storing recieved data from API
export default function App() {
const [data] = useState([
    { id: 1, name: "John" },
    { id: 2, name: "Doe" },
    { id: 3, name: "Smith" }    
])
  return (
    <div>
        <Child data={data}/>
    </div>
  )
}


